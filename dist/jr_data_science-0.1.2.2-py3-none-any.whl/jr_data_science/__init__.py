"""
Quelques functions utiles pour faire de la datascience.
"""
__version__= "0.1.02.02"


